
//import { totalScore } from './quiz.js';

flowers = [];
temp = 4;



created = true;

function setup() {
    let canvas = createCanvas(2016, 1153);
    canvas.parent("GoodCanvasContainer");
    background(150, 214, 205);

   
  }
  


function draw() {

  totalScore = getItem('totalScore');
  
  noStroke();
  fill(72, 140, 55);
  rect(0,800,windowWidth,windowHeight-800);

  if(created === true){
    for(i = 0; i <= totalScore; i++){
      console.log(totalScore);
      flowers[i] = new Flower(random(50, 500), random(700, 900));
    }
    created = false;

  }
  
  // flower1 = new Flower();
  // flower1.display();

  for(i = 0; i < flowers.length; i++){
    flowers[i].display();

  }


  
  
  
  


}



class Flower {
  constructor(x,y) {
    this.x = x;
    this.y = y;
  
  }

  display() {
  //   fill(11, 77, 26);
  //   rect(this.x-5, this.y, 10, 100);
  
  // // Petals
  // fill(255, 204, 0);
  // translate(this.x /4, this.y/4);
  // for (let i = 0; i < 10; i++) {
  //   ellipse(this.x,this.y, 20, 30);
  //   rotate(PI/5);
  // }
  
  // // Center
  // fill(255, 0, 0);
  // ellipse(0, 0, 50, 50);


  fill(11, 77, 26);
  rect(this.x-5, this.y, 10, 100);
  
  fill("yellow")
  ellipse(this.x,this.y+15,20,30)
  ellipse(this.x,this.y-15,20,30)
  
  ellipse(this.x+15,this.y,30,20)
  ellipse(this.x-15,this.y,30,20)
  
  circle(this.x+15,this.y-15,20,20)
  circle(this.x-15,this.y-15,20,20)
  circle(this.x-15,this.y+15,20,20)
  circle(this.x+15,this.y+15,20,20)
  
  
  
  fill("red")
  circle(this.x,this.y,20)



  }

  flowerClicked(){

  }



}