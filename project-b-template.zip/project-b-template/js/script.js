

document.getElementById('toQuiz').addEventListener('click', function() {
  window.location.href = 'quiz.html'; 
})

